package Model;

public class MenssagensModel {
	
	private String menssagem;

	public MenssagensModel(String menssagem) {
		super();
		this.menssagem = menssagem;
	}

	public String getMenssagem() {
		return menssagem;
	}

	public void setMenssagem(String menssagem) {
		this.menssagem = menssagem;
	}
	
	
}
