package Model;

public class administradorModel extends usuariosModel {

	public administradorModel(String nome, String email, String senha) {
		super(nome, email, senha);
		// TODO Auto-generated constructor stub
	}


}
