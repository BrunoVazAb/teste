package Controller;

import java.io.IOException;
import java.util.Date;
import java.util.ArrayList;
import javax.sql.DataSource;

import Model.ChamadoDAO;
import Model.MenssagensModel;
import Model.chamadosModel;
import Model.clienteModel;
import jakarta.annotation.Resource;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ChamadosController")
public class ChamadosController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ChamadoDAO cDAO;
	
	@Resource(name = "bancoTechsolutions")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		cDAO = new ChamadoDAO(dataSource);
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String acao = request.getParameter("acao").toLowerCase();

        switch (acao) {

        case "vertickets":
        	listarChamadosCliente(request, response);
            break;
        case "listarchamados":
        	listarChamados(request, response);
            break;
            
        case "listarchamadostecnico":
        	listarChamadosTecnico(request, response);
        	break;
        	
        case "listarchamadosresolvidos":
        	listarChamadosResolvidos(request, response);
        	break;

        case "assumirchamado":
        	assumirChamados(request, response);
            break;
       
		default:
			System.out.println("Erro! - Operacao nao encontrada");
        }
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String acao = request.getParameter("acao").toLowerCase();

        switch (acao) {

		case "registrar":
			cadastrarChamado(request, response);
		break;
		case "atualizar":
			atualizarStatusChamado(request, response);
			break;
		default:
			System.out.println("Erro! - Operacao nao encontrada");
        }
    }

	private void cadastrarChamado(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		clienteModel cliente = (clienteModel) session.getAttribute("usuarioLogado");
		
		int usuarioId = cliente.getId();
        String prioridade = request.getParameter("prioridade");
        String descricao = request.getParameter("descricao");
        String status = "aberto";
        Date dataAbertura = new Date();
		

		boolean inserido = cDAO.registrarChamado(usuarioId, prioridade, status, descricao, dataAbertura);

		request.setAttribute("status", inserido);
		request.setAttribute("operacao", "cadastrada");
				
		request.getRequestDispatcher("/status.jsp").forward(request, response);
	}
	 
	 public void listarChamadosCliente(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session = request.getSession();
		 clienteModel cliente = (clienteModel) session.getAttribute("usuarioLogado");
		 ArrayList<chamadosModel> listaChamadosCliente = cDAO.listaChamadosCliente(cliente.getId());
		 
		 request.setAttribute("listaChamadosCliente", listaChamadosCliente);
			
		 RequestDispatcher dispatcher = request.getRequestDispatcher("/exibeChamadosCliente.jsp");
			
		 dispatcher.forward(request, response);
	    
	    }
		private void listarChamados(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			ArrayList<chamadosModel> lista = cDAO.listarChamados();
			request.setAttribute("listaChamadosAbertos", lista);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/ChamadosAbertosTecnico.jsp");
			dispatcher.forward(request, response);
				
		}
		 public void listarChamadosTecnico(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			 HttpSession session = request.getSession();
			 clienteModel tecnico = (clienteModel) session.getAttribute("usuarioLogado");
			 ArrayList<chamadosModel> listaChamadosTecnico = cDAO.buscarChamadosAtribuidos(tecnico.getId());
			 
			 request.setAttribute("listaChamadosAtribuidos", listaChamadosTecnico);
			 
			 RequestDispatcher dispatcher = request.getRequestDispatcher("/ChamadosAtribuidos.jsp");
			 
			 dispatcher.forward(request, response);
			 
		 }
		 
		 public void assumirChamados(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			 HttpSession session = request.getSession();
			 clienteModel cliente = (clienteModel) session.getAttribute("usuarioLogado");
				
			  int idChamado = Integer.parseInt(request.getParameter("id"));
			  int tecnicoId = cliente.getId();

		      cDAO.assumirChamados(idChamado, tecnicoId);
		        
		      request.getRequestDispatcher("/ChamadosAtribuidos.jsp").forward(request, response);;

		 }
		 
		 public void atualizarStatusChamado(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        int id = Integer.parseInt(request.getParameter("id"));
		        String novoStatus = request.getParameter("statusChamado");
		        
		        cDAO.atualizarStatusChamado(id, novoStatus); 
		        
			    request.getRequestDispatcher("/DashboardTecnico.jsp").forward(request, response);;

		 }
		 
		 public void listarChamadosResolvidos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			 HttpSession session = request.getSession();
			 clienteModel tecnico = (clienteModel) session.getAttribute("usuarioLogado");
			 ArrayList<chamadosModel> listaChamadosResolvidos = cDAO.buscarChamadosResolvidosTec(tecnico.getId());
			 
			 request.setAttribute("listaChamadosResolvidos", listaChamadosResolvidos);
			 
			 RequestDispatcher dispatcher = request.getRequestDispatcher("/ChamadosResolvidos.jsp");
			 
			 dispatcher.forward(request, response);
			 
		 }
}
